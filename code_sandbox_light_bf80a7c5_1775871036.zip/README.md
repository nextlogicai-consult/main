# NextLogicAI - Business Website

A modern, dark-themed multi-page website for **NextLogicAI Consulting** — an AI integration and consulting firm serving small businesses across Alberta, Canada.

## 🎯 Project Overview

NextLogicAI helps small businesses implement AI tools that save time, cut costs, and scale operations — without the technical overwhelm. This website showcases their services, 6-phase process, pricing packages, blog content, and contact options.

## ✅ Completed Features

### Pages
| Page | File | Description |
|------|------|-------------|
| **Home** | `index.html` | Hero section, services preview, 6-phase process, pricing preview, blog preview, CTA |
| **Services** | `services.html` | 6 detailed service offerings + industry verticals (10+ industries) |
| **Process** | `process.html` | Full 6-phase process with deliverables + FAQ accordion |
| **Packages** | `packages.html` | 3 pricing tiers (Starter $2,500 / Growth $7,500 / Enterprise Custom) + FAQ |
| **About** | `about.html` | Company story, values (6 core values), stats section |
| **Blog** | `blog.html` | 6 blog articles with category filtering (AI Basics, Case Study, Strategy, Industry, Guide) |
| **Blog Post** | `blog-post.html` | Dynamic blog post viewer with related posts |
| **Contact** | `contact.html` | Contact form with package/industry selects, contact info, "What to Expect" section |

### Design & UX
- 🌑 **Dark theme** with cyan (#00E5FF) accent — matching the original design
- 📱 **Fully responsive** — mobile, tablet, desktop, large desktop
- ✨ **Scroll animations** — fade-in, stagger children, count-up counters
- 🎛️ **Interactive elements** — FAQ accordion, blog category filters, mobile navigation
- 🔗 **Consistent navigation** — shared header/footer across all pages with active states
- ♿ **Accessible** — semantic HTML, ARIA labels, focus-visible styles

### Technical Features
- CSS custom properties (design tokens) for consistent theming
- IntersectionObserver for scroll-triggered animations
- Contact form with data submission to API
- Blog post routing via URL parameters (?slug=)
- Package pre-selection from URL params (?package=starter)
- Clean, modular file structure

## 📁 File Structure

```
/
├── index.html              # Home page
├── services.html           # Services page
├── process.html            # Process page
├── packages.html           # Packages & pricing page
├── about.html              # About page
├── blog.html               # Blog listing page
├── blog-post.html          # Dynamic blog post viewer
├── contact.html            # Contact page with form
├── css/
│   ├── style.css           # Main stylesheet (design system)
│   └── responsive.css      # Responsive breakpoints
├── js/
│   ├── main.js             # Core JavaScript (nav, animations, form)
│   └── blog-data.js        # Blog post content data
└── README.md               # This file
```

## 🔗 Functional URIs & Parameters

| URI | Parameters | Description |
|-----|-----------|-------------|
| `index.html` | — | Home page |
| `services.html` | — | Services listing |
| `process.html` | — | 6-phase process + FAQ |
| `packages.html` | — | Pricing packages + FAQ |
| `about.html` | — | Company about page |
| `blog.html` | — | Blog listing with filters |
| `blog-post.html` | `?slug=<post-slug>` | Individual blog post |
| `contact.html` | `?package=<starter\|growth\|enterprise>` | Contact form (pre-fills package) |

### Available Blog Post Slugs
- `what-is-ai-integration`
- `5-ways-ai-saves-time`
- `build-vs-buy-ai`
- `ai-in-alberta-oil-gas`
- `ai-models-explained`
- `preparing-your-business-for-ai`

## 📊 Data Models

### `contact_submissions` table
| Field | Type | Description |
|-------|------|-------------|
| id | text | Unique ID |
| name | text | Contact name |
| email | text | Email address |
| company | text | Company name |
| package | text | Package interest |
| industry | text | Industry |
| message | rich_text | Message content |

### `blog_posts` table
| Field | Type | Description |
|-------|------|-------------|
| id | text | Unique ID |
| slug | text | URL slug |
| title | text | Post title |
| category | text | Category (AI Basics, Case Study, Strategy, Industry, Guide) |
| date | text | Publication date |
| read_time | text | Read time estimate |
| excerpt | text | Short excerpt |
| content | rich_text | Full content |

## 🚀 Recommended Next Steps

1. **Custom domain** — Connect nextlogicai.com to the deployed site
2. **Analytics** — Add Google Analytics or Plausible for visitor tracking
3. **Calendar integration** — Embed Calendly for "Book a Call" functionality
4. **SEO optimization** — Add OG images, sitemap.xml, robots.txt
5. **Testimonials section** — Add client testimonials when available
6. **Case studies** — Create detailed case study pages for portfolio
7. **Newsletter** — Connect the blog subscribe form to an email service (Mailchimp, ConvertKit)
8. **Blog CMS** — Move blog content to the API table for dynamic management
9. **Dark/light mode toggle** — Add user preference for theme switching

## 🛠️ Tech Stack

- **HTML5** — Semantic markup
- **CSS3** — Custom properties, Grid, Flexbox, animations
- **JavaScript** — Vanilla JS, IntersectionObserver, Fetch API
- **Fonts** — Inter + Space Grotesk (Google Fonts)
- **Icons** — Font Awesome 6.4
- **Data** — RESTful Table API for contact form submissions

---

© 2026 NextLogicAI Consulting · Alberta, Canada
